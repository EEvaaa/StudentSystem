import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

public class FileIO
{
    private String workingDirectory;    
    public FileIO()
    {
        workingDirectory = System.getProperty("user.dir");
    }       
    public void saveUsers(ArrayList<User>users, String fileName)
    {
        PrintWriter outputStream = null;
        try
        {
            //create a file output stream
            outputStream = new PrintWriter(new FileOutputStream(fileName ), true);
            ObjectOutputStream outputStream1 = new ObjectOutputStream(new FileOutputStream(fileName));
            //write the User objects in users ArrayList 
            outputStream1.writeObject(users);
            outputStream1.close();
        }
        catch(IOException e)
        {
            System.out.println("Error opening the file " + fileName );
        }
    }    
    public ArrayList<User> loadUsers(String fileName) 
    {
        ArrayList<User> temp = new ArrayList<User>();
        try
        {
            //create a file input stream 
            ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(fileName));
            //read the User objects into an ArrayList
            temp = (ArrayList<User>)inputStream.readObject();
            inputStream.close();
        }
        catch(ClassNotFoundException e)
        {
            System.out.println("Error finding the class");
        }
        catch(IOException e)
        {
            System.out.println("Error opening the file" + fileName);
        }
        return temp;
    }    
}


