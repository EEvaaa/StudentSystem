import java.io.*;
import java.util.*;
public class Student implements Serializable
{
    private String firstName, lastName, gender, finalS;
    private int participation, popQ, assignment,exam,schoolNumber;
    public Student(int schoolNumber, String lastName, String firstName, String gender, int assignment, int participation, int popQ, int exam, String finalS)
    {
        this.schoolNumber = schoolNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.assignment = assignment; 
        this.participation = participation; 
        this.popQ = popQ;
        this.exam = exam;
        this.finalS = finalS;
    }
    //Get school number
    public int getSchoolNumber()
    {
        return schoolNumber;
    }
    //Get first name
    public String getFirstName()
    {
        return firstName;
    }
    //Get last name
    public String getLastName()
    {
        return lastName;
    }
    //Get participation mark
    public int getParticipation()
    {
        return participation;
    }
    //Get pop question mark 
    public int getPopQ()
    {
        return popQ;
    }
    //Get Assignment mark
    public int getAssignment()
    {
        return assignment;
    }
    //Get gender
    public String getGender()
    {
        return gender;
    }
    //Get exam mark
    public int getExam()
    {
        return exam;
    }
    //Get final score
    public String getFinalS()
    {
        return finalS;
    }
    //Set first name
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }
    //Set last name
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }
    //Set school number
    public void setSchoolNumber(int schoolNumber)
    {
        this.schoolNumber = schoolNumber;
    }
    //Set gender
    public void setGender(String gender)
    {
        this.gender = gender;
    }
    //Set participation mark
    public void setParticipation(int participation)
    {
        this. participation = participation;
    }
    //Set assignment mark
    public void setAssignment(int assignment)
    {
        this.assignment = assignment;
    }
    //Set pop question mark
    public void setPopQ(int popQ)
    {
        this.popQ = popQ;
    }
    //Set exam mark
    public void setExam(int exam)
    {
        this.exam = exam;
    }
    //Set final score 
    public void setFinalS(String finalS)
    {
        this.finalS = finalS;
    }
}
    
  