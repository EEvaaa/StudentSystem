import javax.swing.*;
import java.util.Properties;
import javax.mail.*;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
//Send email to the user's email address
public class JavaMail 
{     
    public void sendMail(String name, String password, String email) throws Exception
    {
        Properties props = new Properties();
            props.setProperty("mail.smtp.auth", "true");
            props.setProperty("mail.transport.protocol", "smtp");
            props.put("mail.smtp.host","smtp.163.com");// smtp server address
            
            Session session = Session.getInstance(props);
            session.setDebug(true);
            
            Message msg = new MimeMessage(session);
            msg.setSubject("Password of Student System");
            msg.setText("Dear " + name +","+ "\n" + password + "\n" + "\n" + "Student System Cooperation");
            msg.setFrom(new InternetAddress("eva_liu2002@163.com"));// Sender email
            msg.setRecipient(Message.RecipientType.TO,
                    new InternetAddress(email)); //Recipient's email
            msg.saveChanges();

            Transport transport = session.getTransport();
            transport.connect("eva_liu2002@163.com","EVALYQ789456");//Sender mailbox, authorization code
            
            transport.sendMessage(msg, msg.getAllRecipients());
            JOptionPane.showConfirmDialog(null, "Email has been sent successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            transport.close();
    }
}
