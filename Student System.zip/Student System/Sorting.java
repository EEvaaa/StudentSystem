import javax.swing.*;
import java.util.*;
//Sort methods
public class Sorting extends JFrame
{
    public void ascend(Object[][] data,ArrayList <Student> students,int item,JTable table,JScrollPane scrollPane)
    {        
        for(int i = 0; i < students.size();i++)
        {
            for(int j = 0; j < students.size()-1; j++)
            {
                //Compare the current object value and the next object's value
                if(Integer.parseInt(data[j][item].toString()) > Integer.parseInt(data[j + 1][item].toString()))
                {
                    for(int k = 0; k < 9; k++)
                    {
                        //swap the sequence of the Student objects if the current object's value is greater than next object's value
                        Object temp = data[j][k];
                        data[j][k] = data[j+1][k];
                        data[j+1][k] = temp;
                    }
                }
            }
        }
        //Repaint the table
        table.repaint();
        scrollPane.validate();
        scrollPane.updateUI();
    }

    public void descend(Object[][] data,ArrayList <Student> students,int item,JTable table,JScrollPane scrollPane)
    {
        for(int i = 0; i < students.size();i++)
        {
            for(int j = 0; j < students.size()-1; j++)
            {
                //Compare the current object value and the next object's value
                if(Integer.parseInt(data[j][item].toString()) < Integer.parseInt(data[j + 1][item].toString()))
                {
                    for(int k = 0; k < 9;k++)
                    {
                        //swap the sequence of the Student objects if the current object's value is smaller than next object's value
                        Object temp = data[j][k];
                        data[j][k] = data[j+1][k];
                        data[j+1][k] = temp;
                    }
                }
            }
        }
        //Repaint the table
        table.repaint();
        scrollPane.validate();
        scrollPane.updateUI();
    }

    public void finalAscend(Object[][] data,ArrayList <Student> students,int item,JTable table,JScrollPane scrollPane)
    {
        for(int i = 0; i < students.size();i++)
        {
            for(int j = 0; j < students.size()-1; j++)
            {
                //Compare the current object value and the next object's value
                if(Float.parseFloat(data[j][item].toString()) > Float.parseFloat(data[j + 1][item].toString()))
                {
                    for(int k = 0; k < 9; k++)
                    {
                        //swap the sequence of the Student objects if the current object's value is greater than next object's value
                        Object temp = data[j][k];
                        data[j][k] = data[j+1][k];
                        data[j+1][k] = temp;
                    }
                }
            }
        }
        table.repaint();
        scrollPane.validate();
        scrollPane.updateUI();
    }

    public void finalDescend(Object[][] data,ArrayList <Student> students,int item,JTable table,JScrollPane scrollPane)
    {
        for(int i = 0; i < students.size();i++)
        {
            for(int j = 0; j < students.size()-1; j++)
            {
                //Compare the current object value and the next object's value
                if(Float.parseFloat(data[j][item].toString()) < Float.parseFloat(data[j + 1][item].toString()))
                {
                    for(int k = 0; k < 9;k++)
                    {
                        //swap the sequence of the Student objects if the current object's value is smaller than next object's value
                        Object temp = data[j][k];
                        data[j][k] = data[j+1][k];
                        data[j+1][k] = temp;
                    }
                }
            }
        }
        table.repaint();
        scrollPane.validate();
        scrollPane.updateUI();
    }
}
