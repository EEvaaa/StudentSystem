import java.util.*;
public class Client
{
    public static void main(String[] args) 
   {
       //FileIO io = new FileIO();
       //ArrayList<User> temp = new ArrayList<User>();
       //io.saveUsers(temp, "Accounts");
       Login myLogin = new Login();
    }
}
