// https://docs.oracle.com/javase/tutorial/uiswing/components/table.html
//https://blog.csdn.net/ryan007liu/article/details/89357447
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import java.io.*;
import java.text.*;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import java.net.URL;
public class StudentSystem extends JFrame
{
    private Container contents;
    private JTable table;

    private JRadioButton ascend, descend, searchLast, searchFirst,searchSN,graphAssignment, graphParticipation, graphPopQ, graphExam, graphFinalS;
    private JButton btnUpload,btnWrite,btnSetting,btnCalculate,btnClear,btnSort,btnRandom,btnSearch, btnBarChart, btnCalculator,btnSave,btnPrevious,btnNext;
    private JScrollPane scrollPane;
    private ImageIcon background;
    private float assignmentP, participationP, popQP, examP;
    private JTextField txtAssignment, txtParticipation, txtPopQ, txtExam;
    private JLabel lblAssignment, lblParticipation,lblPopQ, lblExam, lblPercent1, lblPercent2, lblPercent3, lblPercent4,lblPercent5,lblRemain,lblRLabel;
    private boolean finishSetting = false,finishFinalS = false;
    private int searchCount;

    private JComboBox<String> sortCombo;

    private String[] columnNames = {
            "School Number",
            "Last Name",
            "First Name",
            "Gender",
            "Assignment",
            "Participation",
            "Pop Question",
            "Exam",
            "Final"};
    private Object[][] data;

    private ArrayList <Student> students;
    private ArrayList<Integer> search;

    private JMenuBar menuBar;
    private JMenu menuHelp, menuExit;
    private JMenuItem menuIC, menuIIns, menuIE, menuIL;

    public StudentSystem()
    {
        super("Student Information System");
        contents = getContentPane();
        contents.setLayout(new BorderLayout());

        contents.add(topPane(), BorderLayout.NORTH);
        contents.add(leftPane(), BorderLayout.WEST);
        contents.add(tablePane(), BorderLayout.CENTER);
        contents.add(bottomPane(),BorderLayout.SOUTH);

        students = new ArrayList<Student>();
        menuBar = menu();
        this.setJMenuBar(menuBar);

        setSize(1100,800);
        this.setLocationRelativeTo(null);
        setResizable(false);
        setVisible( true );
    }
    //Menu Bar
    public JMenuBar menu()
    {
        menuBar = new JMenuBar();
        menuHelp = new JMenu("Help");
        menuExit = new JMenu("Exit");
        menuIL = new JMenuItem("Exit to Login");
        menuIE = new JMenuItem("Exit the App");
        menuIC = new JMenuItem("Contact");
        menuIIns = new JMenuItem("Instruction");
        menuExit.add(menuIL);
        menuExit.add(menuIE);
        menuHelp.add(menuIC);
        menuHelp.add(menuIIns);
        menuBar.add(menuExit);
        menuBar.add(menuHelp);

        Action a = new Action();
        menuIC.addActionListener(a);
        menuIIns.addActionListener(a);
        menuIL.addActionListener(a);
        menuIE.addActionListener(a);
        return menuBar;
    }
    //Title 
    public JComponent topPane()
    {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        panel.setPreferredSize(new Dimension(1100,50));
        JLabel lblTitle = new JLabel("Welcome to Student Grading System");

        panel.add(lblTitle);

        return panel;
    }
    //Function buttons
    public JComponent leftPane()
    {
        JPanel panel = new JPanel(new GridLayout(9,1,20,20));

        btnUpload = new JButton("Import Excel");
        btnWrite = new JButton("Export Excel");
        btnSetting = new JButton("Setting");
        btnCalculate = new JButton("Calculate Final Score");
        btnRandom = new JButton("Random");
        btnSave = new JButton("Save");
        btnCalculator = new JButton("Calculator");

        panel.add(btnUpload);
        panel.add(btnWrite);
        panel.add(btnCalculate);
        panel.add(btnRandom);
        panel.add(btnSave);
        panel.add(btnCalculator);

        Action ac = new Action();
        btnUpload.addActionListener(ac);
        btnWrite.addActionListener(ac);
        btnCalculate.addActionListener(ac);
        btnRandom.addActionListener(ac);
        btnCalculator.addActionListener(ac);
        btnSave.addActionListener(ac);

        add(panel);
        setLayout(new FlowLayout());
        setLocationRelativeTo(null);

        return panel;
    }
    //table
    public JComponent tablePane(){
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        panel.setPreferredSize(new Dimension(850,550));

        data = new Object[100][9];

        table = new JTable(data, columnNames);
        //table.setDefaultEditor(Object.class, null);
        table.setPreferredScrollableViewportSize(new Dimension(750,550));
        table.setFillsViewportHeight(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setRowSelectionAllowed(true);
        table.setColumnSelectionAllowed(false);

        scrollPane = new JScrollPane(table);
        panel.add(scrollPane);

        return panel;
    }
    //Setting
    public JComponent OptionTabSetting()
    {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        panel.setPreferredSize(new Dimension(850,100));

        lblAssignment = new JLabel("Assignment");
        txtAssignment = new JTextField("", 8);
        lblPercent1 = new JLabel("%  ");
        lblParticipation = new JLabel("Participation");
        txtParticipation = new JTextField("", 8);
        lblPercent2 = new JLabel("%  ");
        lblPopQ = new JLabel("Pop Question");
        txtPopQ = new JTextField("",8);
        lblPercent3 = new JLabel("%  ");
        lblExam = new JLabel("Exam");
        txtExam = new JTextField("",8);
        lblPercent4 = new JLabel("%  ");

        btnClear = new JButton("Clear");
        btnSetting = new JButton("Setting");
        lblRemain = new JLabel("100.00");
        lblPercent5 = new JLabel("%");
        lblRLabel = new JLabel("Remain");

        panel.add(lblAssignment);
        panel.add(txtAssignment);
        panel.add(lblPercent1);
        panel.add(lblParticipation);
        panel.add(txtParticipation);
        panel.add(lblPercent2);
        panel.add(lblPopQ);
        panel.add(txtPopQ);
        panel.add(lblPercent3);
        panel.add(lblExam);
        panel.add(txtExam);
        panel.add(lblPercent4);
        panel.add(btnSetting);
        panel.add(btnClear);
        panel.add(lblRLabel);
        panel.add(lblRemain);
        panel.add(lblPercent5);

        Action ac = new Action();
        btnClear.addActionListener(ac);
        btnSetting.addActionListener(ac);

        Focus f = new Focus();
        txtAssignment.addFocusListener(f);
        txtParticipation.addFocusListener(f);
        txtPopQ.addFocusListener(f);
        txtExam.addFocusListener(f);
        return panel;
    }
    //Sort
    public JComponent OptionTabSort()
    {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        panel.setPreferredSize(new Dimension(850,100));

        JLabel lblTitle = new JLabel("Please select your sorting method and sorting item.");

        ascend = new JRadioButton("Ascending Sort");
        descend = new JRadioButton("Descending Sort");

        String sortItem[] = {"","Assignment","Participation","Pop Question", "Exam","Final Score"};
        sortCombo = new JComboBox(sortItem);        

        ascend.setForeground(Color.BLUE);
        descend.setBackground(Color.RED);

        ButtonGroup radioButtons = new ButtonGroup();
        radioButtons.add(ascend);
        radioButtons.add(descend);

        btnSort = new JButton("Sort");

        panel.add(lblTitle);
        panel.add(sortCombo);
        panel.add(ascend);
        panel.add(descend);
        panel.add(btnSort);

        Action ac = new Action();
        btnSort.addActionListener(ac);

        panel.setLayout(new FlowLayout());

        return panel;
    }
    //Draw Bar Chart
    public JComponent OptionTabGraph()
    {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        panel.setPreferredSize(new Dimension(850,100));

        JLabel lblTitle = new JLabel("Please select your graphing item.");

        graphAssignment = new JRadioButton("Assignment");
        graphParticipation = new JRadioButton("Participation");
        graphPopQ = new JRadioButton("Pop Question");
        graphExam = new JRadioButton("Exam");
        graphFinalS = new JRadioButton("Final Score");

        ButtonGroup radioButtons = new ButtonGroup();
        radioButtons.add(graphAssignment);
        radioButtons.add(graphParticipation);
        radioButtons.add(graphPopQ);
        radioButtons.add(graphExam);
        radioButtons.add(graphFinalS);

        btnBarChart = new JButton("Draw Bar Chart");

        panel.add(lblTitle);
        panel.add(graphAssignment);
        panel.add(graphParticipation);
        panel.add(graphPopQ);
        panel.add(graphExam);
        panel.add(graphFinalS);
        panel.add(btnBarChart);

        panel.setLayout(new FlowLayout());

        Action ac = new Action();
        btnBarChart.addActionListener(ac);

        return panel;
    }
    //Search
    public JComponent OptionTabSearch()
    {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        panel.setPreferredSize(new Dimension(850,100));

        JLabel lblTitle = new JLabel("Please select the searching method:");

        searchLast = new JRadioButton("Last Name");
        searchFirst = new JRadioButton("First Name");
        searchSN = new JRadioButton("School Number");

        ButtonGroup radioButtons = new ButtonGroup();
        radioButtons.add(searchLast);
        radioButtons.add(searchFirst);
        radioButtons.add(searchSN);

        btnSearch = new JButton("Search");
        btnPrevious = new JButton("<");
        btnNext = new JButton(">");

        panel.add(lblTitle);
        panel.add(searchLast);
        panel.add(searchFirst);
        panel.add(searchSN);
        panel.add(btnSearch);
        panel.add(btnPrevious);
        panel.add(btnNext);

        Action ac = new Action();
        btnSearch.addActionListener(ac);
        btnPrevious.addActionListener(ac);
        btnNext.addActionListener(ac);

        panel.setLayout(new FlowLayout());
        return panel;
    }

    public JComponent bottomPane()
    {
        JPanel panel = new JPanel();
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Setting", OptionTabSetting());
        tabbedPane.addTab("Sort",OptionTabSort());
        tabbedPane.addTab("Search",OptionTabSearch());
        tabbedPane.addTab("Graph", OptionTabGraph());
        panel.add(tabbedPane);
        panel.setLayout(new FlowLayout());
        panel.setPreferredSize(new Dimension(900,150));      
        return panel;
    }

    // Search the student's information by inputting last name
    public ArrayList<Integer> searchL(String target)
    {
        ArrayList<Integer> temp = new ArrayList<Integer>();
        for(int i = 0 ; i < students.size(); i++ )
        {
            boolean result = students.get(i).getLastName().contains(target);
            if(result == true)
            {
                temp.add(i);
            }
        }
        return temp;
    }

    // Search the student's information by inputting first name
    public ArrayList<Integer> searchF(String target)
    {
        ArrayList<Integer> temp = new ArrayList<Integer>();
        for(int i = 0 ; i < students.size(); i++ )
        {
            boolean result = students.get(i).getFirstName().contains(target);
            if(result == true)
            {
                temp.add(i);
            }
        }
        return temp;
    }

    // Search the student's information by inputting school number 
    public ArrayList<Integer> searchS(String target)
    {
        ArrayList<Integer> temp = new ArrayList<Integer>();
        for(int i = 0 ; i < students.size(); i++ )
        {
            String snTemp= String.valueOf(students.get(i).getSchoolNumber());
            boolean result = snTemp.contains(target);
            if(result == true)
            {
                temp.add(i);
            }
        }
        return temp;
    }

    public  void getResource() throws IOException
    {	
        //查找指定资源的URL，其中res.txt仍然开始的bin目录下 
        URL fileURL=this.getClass().getResource("/resource/res.xls"); 
        System.out.println(fileURL.getFile());
    }

    private class Focus implements FocusListener
    {
        //variables 
        private double assignment = 0, participation = 0, popQ = 0, exam = 0,d;
        public void focusGained(FocusEvent fe) 
        {
            //Whenever users input numbers in a text area, all numbers are set to be zero. 
            if(fe.getSource() == txtAssignment)
            {
                assignment = 0;
            }
            else if(fe.getSource() == txtParticipation)
            {
                participation = 0;
            }
            else if(fe.getSource() == txtPopQ)
            {
                popQ = 0;
            }
            else if(fe.getSource() == txtExam)
            {
                exam = 0;
            }
        }

        public void focusLost(FocusEvent e) 
        {
            try
            {
                //Whenever users leaves a text area, the system calculates the remaining percentages
                if(e.getSource() == txtAssignment)
                {
                    assignment = Double.parseDouble(txtAssignment.getText());
                    //Set decimal format
                    DecimalFormat decimalFormat=new DecimalFormat(".00");
                    d = 100.00;
                    double result = d - assignment - participation - popQ - exam;
                    String temp = decimalFormat.format(result);
                    //Update the remain
                    lblRemain.setText(temp);
                }
                else if(e.getSource() == txtParticipation)
                {
                    participation = Double.parseDouble(txtParticipation.getText());
                    //Set decimal format
                    DecimalFormat decimalFormat=new DecimalFormat(".00");
                    d = 100.00;
                    double result = d - assignment - participation - popQ - exam;
                    String temp = decimalFormat.format(result);
                    //Update the remain
                    lblRemain.setText(temp);
                }
                else if(e.getSource() == txtPopQ)
                {
                    popQ = Double.parseDouble(txtPopQ.getText());
                    //Set decimal format
                    DecimalFormat decimalFormat=new DecimalFormat(".00");
                    d = 100.00;
                    double result = d - assignment - participation - popQ - exam;
                    String temp = decimalFormat.format(result);
                    //Update the remain
                    lblRemain.setText(temp);
                }
                else if(e.getSource() == txtExam)
                {
                    exam = Double.parseDouble(txtExam.getText());
                    //Set decimal format
                    DecimalFormat decimalFormat=new DecimalFormat(".00");
                    d = 100.00;
                    double result = d - assignment - participation - popQ - exam;
                    String temp = decimalFormat.format(result);
                    //Update the remain
                    lblRemain.setText(temp);
                }
            }
            catch(Exception IOException)
            {

            }
        }
    }

    private class Action implements ActionListener
    {
        public void actionPerformed(ActionEvent ae) 
        {
            try
            {                
                //Exit the program
                if(ae.getSource() == menuIE)
                {
                    dispose();
                }
                //Exit to the login interface
                else if(ae.getSource() == menuIL)
                {
                    dispose();
                    Login l = new Login();
                }
                //Contact to the author 
                else if(ae.getSource() == menuIC)
                {
                    JOptionPane.showMessageDialog(null, "If you have any question, please contact me.\n\n Eva Liu  Email: eva_liu2002@163.com." + "\n\n" +
                        "Thank you for choosing this system." + "\n\n\n" + "Produced by: Liu Yiqian (Eva) \n\n Version 2020",
                        "Contact",JOptionPane.PLAIN_MESSAGE);
                }
                //Instruction
                else if(ae.getSource() == menuIIns)
                {
                    JOptionPane.showMessageDialog(null, 
                        "1.This application consists of function buttons at left side, table, menu, and funtion group at the bottom." + "\n"
                        + "2.Import Excel button: you can choose the excel(.xls) from your computer and print in the table." + "\n"
                        + "3.Export Excel button: you can export the newest version of the student data in the table."+"\n"
                        + "4.Calculate Final Score button: you can calculate the final score of each student after you set the percentages of each item." + "\n"
                        + "5.Random button: it can randomly print out a student to answer the question during the class." + "\n"
                        + "6.Save button: after you edit in the table, you must click this button to save."+ "\n"
                        + "7.Calculate button: whenever you would like to use calculator, just click this button." + "\n"
                        + "8.Setting: You must set percentages of each item before deal with issues of final score. You should input numbers without %." + "\n"
                        + "               The inputs are shown on the screen to remind the precise percentage of each item without clicking clear button." + "\n"
                        + "               Clear button is to clear all the inputs. " + "\n"
                        + "9.Sort: You can select the item to sort at the combo boxes and sorting method." + "\n"
                        + "10.Search: You can search a specific student's information by using this method." + "\n"
                        + "11.Graph: You need to select the item to draw and then click the Draw Bar Chart button." + "\n"
                        + "12.Exit to Login: Go back to the Login."+ "\n"
                        + "13.Exit the application: close the whole application" + "\n"
                        + "Hope you enjoy the application and if you have any question, please contat me.",
                        "Instruction",JOptionPane.PLAIN_MESSAGE);
                }
                //Upload an excel 
                if(ae.getSource() == btnUpload)
                {
                    //Initiate JFileChooser
                    final JFileChooser fc = new JFileChooser();
                    JLabel lb = new JLabel("Please choose the file you would like to upload.");
                    fc.setApproveButtonText("Confirm");
                    int returnVal = fc.showOpenDialog(lb);
                    fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
                    if(returnVal == JFileChooser.APPROVE_OPTION)
                    {
                        File file = fc.getSelectedFile();
                        String name = file.getName();
                        //Check whether the file's format is an excel 
                        if (file.getAbsolutePath().substring(file.getAbsolutePath().length() -4,file.getAbsolutePath().length()).equals(".xls"))
                        {
                            // Find the Excel
                            Workbook workbook = Workbook.getWorkbook(file);
                            // Find all the workbooks
                            Sheet[] sheets = workbook.getSheets();
                            if (sheets != null)
                            {
                                for (Sheet sheet : sheets)
                                {
                                    // Read the number of rows
                                    int rows = sheet.getRows();
                                    // Read the data
                                    for (int row = 0; row < rows; row++)
                                    {
                                        for (int col = 0; col < 9; col++)
                                        {
                                            //Instantiate two-dimensional array
                                            data[row][col]=sheet.getCell(col, row).getContents();                                   
                                        }                                
                                    }
                                }
                            }
                            workbook.close();
                            scrollPane.validate();
                            scrollPane.updateUI();
                            try 
                            {
                                //Instantiate student objects in the arraylist
                                for(int i = 0; i < 100; i++)
                                {
                                    int schoolNumber = Integer.parseInt(data[i][0].toString());
                                    String lastName = data[i][1].toString();
                                    String firstName = data[i][2].toString();
                                    String gender = data[i][3].toString();
                                    int assignment = Integer.parseInt(data[i][4].toString());
                                    int participation = Integer.parseInt(data[i][5].toString());
                                    int popQ = Integer.parseInt(data[i][6].toString());
                                    int exam = Integer.parseInt(data[i][7].toString());
                                    String finalS = data[i][8].toString();
                                    students.add(new Student(schoolNumber,lastName,firstName,gender,assignment,participation,popQ,exam,finalS));
                                    System.out.println(schoolNumber+" "+lastName+" "+firstName+" "+gender+" "+assignment+" "+participation+" "+popQ+" "+exam+" "+finalS);
                                }
                                JOptionPane.showMessageDialog(null, "Excel has been read successfully","Success", JOptionPane.PLAIN_MESSAGE);
                            }
                            catch(Exception e)
                            {   

                            }
                        }
                        else
                        {
                            //A wrong format document is selected
                            JOptionPane.showMessageDialog(null, "File selected is not xls format.", "Wrong format",
                                JOptionPane.ERROR_MESSAGE);
                        }
                    }
                    //There is no file selected
                    else if(returnVal == JFileChooser.CANCEL_OPTION)
                    {
                        JOptionPane.showMessageDialog(null, "No File Selected.", "No File",
                            JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                //Export an excel 
                else if(ae.getSource() == btnWrite)
                {
                    //JOptionPane.showMessageDialog(null, "The table has already been exported.", "Success",JOptionPane.INFORMATION_MESSAGE);
                    JFrame parentFrame = new JFrame();

                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setDialogTitle("Specify a file to save");   

                    int userSelection = fileChooser.showSaveDialog(parentFrame);

                    if (userSelection == JFileChooser.APPROVE_OPTION) 
                    {
                        File xlsFile = fileChooser.getSelectedFile();
                        String fileName = xlsFile.getCanonicalPath();
                        xlsFile = new File(fileName + ".xls");
                        // Build a new sheet
                        WritableWorkbook workbook = Workbook.createWorkbook(xlsFile);
                        // Build a new workbook
                        WritableSheet sheet = workbook.createSheet("sheet1", 0);
                        for (int row = 0; row < 100; row++)
                        {
                            // Write Data in the sheets
                            for(int col = 0; col < 9; col++)
                            {
                                if(data[row][col] != null)
                                {
                                    sheet.addCell(new Label(col, row,data[row][col].toString()));
                                }
                            }
                        }
                        workbook.write();
                        workbook.close();
                        System.out.println("Save as file: " + xlsFile.getAbsolutePath());
                        ////Open the excel on the desktop
                        Desktop.getDesktop().open(new File(fileName+ ".xls"));
                    }

                }
                //Setting percentages for the four items 
                else if(ae.getSource() == btnSetting)
                {
                    try
                    {
                        lblAssignment.setForeground(new Color(0,0,0));
                        lblParticipation.setForeground(new Color(0,0,0));
                        lblPopQ.setForeground(new Color(0,0,0));
                        lblExam.setForeground(new Color(0,0,0));
                        //Mention users which boxes have not been inputted numbers
                        if(txtAssignment.getText().length()<1 || txtParticipation.getText().length()<1 || txtPopQ.getText().length()<1 || txtExam.getText().length()<1)
                        {
                            JOptionPane.showMessageDialog(null, "Please enter percentages you would like to set in the boxes above.", "Error", JOptionPane.ERROR_MESSAGE);
                            if(txtAssignment.getText().length()<1)
                            {
                                lblAssignment.setForeground(new Color(255,0,0));
                            }
                            else
                            {
                                lblAssignment.setForeground(new Color(0,0,0));
                            }
                            if(txtParticipation.getText().length()<1)
                            {
                                lblParticipation.setForeground(new Color(255,0,0));
                            }   
                            else 
                            {
                                lblParticipation.setForeground(new Color(0,0,0));
                            }
                            if(txtPopQ.getText().length()<1)
                            {
                                lblPopQ.setForeground(new Color(255,0,0));
                            }
                            else 
                            {
                                lblPopQ.setForeground(new Color(0,0,0));
                            }
                            if(txtExam.getText().length()<1)
                            {
                                lblExam.setForeground(new Color(255,0,0));
                            }
                            else
                            {
                                lblExam.setForeground(new Color(0,0,0));
                            }
                        }
                        else if(Float.parseFloat(txtAssignment.getText()) + Float.parseFloat(txtParticipation.getText()) + Float.parseFloat(txtPopQ.getText())
                        + Float.parseFloat(txtExam.getText()) != 100)
                        {
                            JOptionPane.showMessageDialog(null, "Please enter numbers that the sum of all four items is 100%.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                        else 
                        {                        
                            assignmentP = Float.parseFloat(txtAssignment.getText());  
                            participationP = Float.parseFloat(txtParticipation.getText());
                            popQP = Float.parseFloat(txtPopQ.getText());
                            examP = Float.parseFloat(txtExam.getText());
                            JOptionPane.showMessageDialog(null, "You have successfully set the percentages.", "Success", JOptionPane.PLAIN_MESSAGE);
                            lblAssignment.setForeground(new Color(0,0,0));
                            lblParticipation.setForeground(new Color(0,0,0));
                            lblExam.setForeground(new Color(0,0,0));
                            lblPopQ.setForeground(new Color(0,0,0));
                            finishSetting = true;
                        }                                           
                    }
                    catch(Exception NumberFormatException)
                    {
                        JOptionPane.showMessageDialog(null, "Please reenter the percentages. Please enter a number. Thanks!", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                    }                    
                }
                //Clear inputs of setting boxes
                else if(ae.getSource() == btnClear)
                {
                    txtAssignment.setText("");
                    txtParticipation.setText("");
                    txtPopQ.setText("");
                    txtExam.setText("");
                    lblRemain.setText("100.00");
                }
                //Calculate final score 
                else if(ae.getSource() == btnCalculate)
                {
                    if(finishSetting == true)
                    {
                        for(int i = 0; i < students.size(); i++)
                        {
                            int schoolNumber = Integer.parseInt(data[i][0].toString());
                            String lastName = data[i][1].toString();
                            String firstName = data[i][2].toString();
                            String gender = data[i][3].toString();
                            int assignment = Integer.parseInt(data[i][4].toString());
                            int participation = Integer.parseInt(data[i][5].toString());
                            int popQ = Integer.parseInt(data[i][6].toString());
                            int exam = Integer.parseInt(data[i][7].toString());
                            float percent = (float) 0.01;
                            float finalS = assignment*assignmentP*percent + participation*participationP*percent + popQ*popQP*percent + exam*examP*percent;
                            DecimalFormat decimalFormat=new DecimalFormat(".00");
                            String finalS1 = decimalFormat.format(finalS);
                            data[i][8] = finalS1;
                            students.get(i).setFinalS(finalS1);
                        }
                        scrollPane.validate();
                        scrollPane.updateUI();   
                        JOptionPane.showMessageDialog(null, "Final scores have successfully calculated.", "Success", JOptionPane.PLAIN_MESSAGE);
                        finishFinalS = true;
                    }
                    else 
                    {
                        JOptionPane.showMessageDialog(null, "Please complete setting.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
                //Sort 
                else if(ae.getSource() ==btnSort)
                {
                    //Ensure the user's sorting method
                    String sortChoice =(String)sortCombo.getItemAt(sortCombo.getSelectedIndex());
                    //Initiate Sort class
                    Sorting sort = new Sorting();
                    if(!ascend.isSelected() && !descend.isSelected()|| sortChoice == "")
                    {
                        //If users do not select Sorting method or item, the message will be shown on the screen
                        JOptionPane.showMessageDialog(null, "Please select a sorting method and sorting item.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    //Sort by assignment grades
                    else if(sortChoice == "Assignment")
                    {
                        if(ascend.isSelected())
                        {
                            //Call ascend method in Sort class
                            sort.ascend(data,students,4,table,scrollPane);
                        }
                        else if(descend.isSelected())
                        {
                            //Call descend method in Sort class
                            sort.descend(data,students,4,table,scrollPane);
                        }
                    }
                    //Sort by participation grades
                    else if(sortChoice == "Participation")
                    {
                        if(ascend.isSelected())
                        {
                            //Call ascend method in Sort class
                            sort.ascend(data,students,5,table,scrollPane);                            
                        }
                        else if(descend.isSelected())
                        {
                            //Call descend method in Sort class
                            sort.descend(data,students,5,table,scrollPane);
                        }
                    }
                    //Sort by pop question grades
                    else if(sortChoice == "Pop Question")
                    {
                        if(ascend.isSelected())
                        {
                            //Call ascend method in Sort class
                            sort.ascend(data,students,6,table,scrollPane);                            
                        }
                        else if(descend.isSelected())
                        {
                            //Call descend method in Sort class
                            sort.descend(data,students,6,table,scrollPane);
                        }
                    }
                    //Sort by exam grades
                    else if(sortChoice == "Exam")
                    {
                        if(ascend.isSelected())
                        {
                            //Call ascend method in Sort class
                            sort.ascend(data,students,7,table,scrollPane);                            
                        }
                        else if(descend.isSelected())
                        {
                            //Call descend method in Sort class
                            sort.descend(data,students,7,table,scrollPane);
                        }
                    }
                    //Sort by final score grades
                    else if(sortChoice == "Final Score")
                    {                        
                        if(finishFinalS == true)
                        {
                            if(ascend.isSelected())
                            {
                                sort.finalAscend(data,students,8,table,scrollPane);                            
                            }
                            else if(descend.isSelected())
                            {
                                sort.finalDescend(data,students,8,table,scrollPane);
                            }                              
                        }  
                        else 
                        {
                            JOptionPane.showMessageDialog(null, "Please calculate the final score first.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
                //Random print a student's name
                else if(ae.getSource() == btnRandom)
                {
                    Random random =  new Random();
                    int a = random.nextInt(10);
                    String name = students.get(a).getLastName() + " " + students.get(a).getFirstName();
                    JOptionPane.showMessageDialog(null, "Please "+name+" answer the question.", "Answer Question", JOptionPane.PLAIN_MESSAGE);
                }
                //Save the newly editted table
                else if(ae.getSource()== btnSave)
                {
                    System.out.println("0");
                    for(int i = 0; i<100; i++)
                    {
                        for(int j = 0; j < 9; j++)
                        {
                            data[i][j] = table.getValueAt(i,j);
                        }
                    }
                    JOptionPane.showMessageDialog(null, "The editted data have been saved successfully","Success",JOptionPane.PLAIN_MESSAGE);
                    try 
                    {
                        ArrayList<Student> temp = new ArrayList<Student>();
                        for(int i = 0; i < 100; i++)
                        {
                            int schoolNumber = Integer.parseInt(data[i][0].toString());
                            String lastName = data[i][1].toString();
                            String firstName = data[i][2].toString();
                            String gender = data[i][3].toString();
                            int assignment = Integer.parseInt(data[i][4].toString());
                            int participation = Integer.parseInt(data[i][5].toString());
                            int popQ = Integer.parseInt(data[i][6].toString());
                            int exam = Integer.parseInt(data[i][7].toString());
                            String finalS = data[i][8].toString();
                            temp.add(new Student(schoolNumber,lastName,firstName,gender,assignment,participation,popQ,exam,finalS));
                            //System.out.println(temp.get(i).getSchoolNumber());
                            students = temp; 
                            //System.out.println(students.get(i).getSchoolNumber());
                        }

                    }
                    catch(Exception e)
                    {   
                    }
                }
                //Search
                else if(ae.getSource() == btnSearch)
                {
                    int index = 0;

                    try 
                    {
                        ArrayList<Student> temp = new ArrayList<Student>();
                        for(int i = 0; i < 100; i++)
                        {
                            int schoolNumber = Integer.parseInt(data[i][0].toString());
                            String lastName = data[i][1].toString();
                            String firstName = data[i][2].toString();
                            String gender = data[i][3].toString();
                            int assignment = Integer.parseInt(data[i][4].toString());
                            int participation = Integer.parseInt(data[i][5].toString());
                            int popQ = Integer.parseInt(data[i][6].toString());
                            int exam = Integer.parseInt(data[i][7].toString());
                            String finalS = data[i][8].toString();
                            temp.add(new Student(schoolNumber,lastName,firstName,gender,assignment,participation,popQ,exam,finalS));
                            //System.out.println(temp.get(i).getSchoolNumber());
                            students = temp; 
                            //System.out.println(students.get(i).getSchoolNumber());
                        }

                    }
                    catch(Exception e)
                    {   
                    }
                    if(!searchFirst.isSelected() && !searchLast.isSelected()&&!searchSN.isSelected())
                    {
                        JOptionPane.showMessageDialog(null, "Please select a searching method.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    else if(searchLast.isSelected())
                    {
                        String target = JOptionPane.showInputDialog(null, "Enter last name you would like to search");
                        //call searchL method
                        search = searchL(target);
                        if(search.size() == 0)
                        {
                            JOptionPane.showMessageDialog(null, "Last Name is not found", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                        else
                        {
                            searchCount = 0;
                            index = search.get(searchCount);
                            table.setRowSelectionInterval(index, index);
                        }
                    }
                    else if(searchFirst.isSelected())
                    {
                        String target = JOptionPane.showInputDialog(null, "Enter last name you would like to search");
                        //call searchF method
                        search = searchF(target);
                        if(search.size() == 0)
                        {
                            JOptionPane.showMessageDialog(null, "First Name is not found", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                        else
                        {
                            searchCount = 0;
                            index = search.get(searchCount);
                            table.setRowSelectionInterval(index,index);
                        }
                    }
                    else if(searchSN.isSelected())
                    {
                        String target = JOptionPane.showInputDialog(null, "Enter last name you would like to search");
                        //call searchF method
                        search = searchS(target);
                        if(search.size() == 0)
                        {
                            JOptionPane.showMessageDialog(null, "School number is not found", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                        else
                        {
                            searchCount = 0;
                            index = search.get(searchCount);
                            table.setRowSelectionInterval(index,index);
                        }
                    }
                }
                //Highlight next searching result in the table
                else if(ae.getSource() == btnNext)
                {
                    if(searchCount==search.size()-1)
                    {
                        searchCount = 0;
                    }
                    else
                    {
                        searchCount = searchCount +1;
                    }
                    int i = search.get(searchCount);
                    table.setRowSelectionInterval(i,i);
                }
                //Highlight previous searching result in the table 
                else if(ae.getSource() == btnPrevious)
                {
                    searchCount = searchCount - 1;
                    if(searchCount < 0)
                    {
                        searchCount = search.size()-1;
                    }

                    int i = search.get(searchCount);
                    table.setRowSelectionInterval(i,i);
                }
                //Draw Bar chart
                else if(ae.getSource() == btnBarChart)
                {
                    Drawing d = new Drawing(students);
                    if(!graphAssignment.isSelected() && !graphParticipation.isSelected() && !graphPopQ.isSelected() && 
                    !graphExam.isSelected() && !graphFinalS.isSelected())
                    {
                        JOptionPane.showMessageDialog(null, "Please select a graphing item.", "Error", JOptionPane.ERROR_MESSAGE);                        
                    }
                    else if(graphAssignment.isSelected())
                    {
                        d.drawAssignment();
                    }
                    else if(graphParticipation.isSelected())
                    {
                        d.drawParticipation();
                    }
                    else if(graphPopQ.isSelected())
                    {
                        d.drawPopQ();
                    }
                    else if(graphExam.isSelected())
                    {
                        d.drawExam();
                    }
                    else if(graphFinalS.isSelected())
                    {
                        if(finishFinalS == true)
                        {
                            d.drawFinalS();
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null, "Please calculate the final score first.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
                //Calculator
                else if(ae.getSource() == btnCalculator)
                {
                    Calculator c = new Calculator();
                    c.show();
                }
            }
            catch(Exception ex)
            {
                JOptionPane.showMessageDialog(null, "Unknown error", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    public static void main(String[] args)
    {
        StudentSystem ss = new StudentSystem();
    }
}

