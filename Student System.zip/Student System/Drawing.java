import java.util.*;
import java.io.*;
public class Drawing
{
    private ArrayList<Student> students;
    private String[] lastNames;
    private String[] firstNames;
    public Drawing(ArrayList<Student> students)
    {
        this.students = students;
        lastNames = new String[students.size()];
        firstNames = new String[students.size()];
        for(int i = 0; i< lastNames.length; i++)
        {
            lastNames[i] = students.get(i).getLastName();
            firstNames[i] = students.get(i).getFirstName();
        }         
    }
    //Draw assignment bar chart
    public void drawAssignment()
    {
        int[] assignment = new int[students.size()];
        for(int i = 0; i< assignment.length; i++)
        {
            assignment[i] = students.get(i).getAssignment();
        }
        BarChart bc = new BarChart(assignment, lastNames, firstNames,"Assignment");
    }
    //Draw participation bar chart
    public void drawParticipation()
    {
        int[] participation = new int[students.size()];
        for(int i = 0; i< participation.length;i++)
        {
            participation[i] = students.get(i).getParticipation();
        }
        BarChart bc = new BarChart(participation, lastNames, firstNames, "Participation");
    }
    //Draw pop question bar chart
    public void drawPopQ()
    {
        int[] popQ = new int[students.size()];
        for(int i = 0; i< popQ.length; i++)
        {
            popQ[i] = students.get(i).getPopQ();
        }
        BarChart bc = new BarChart(popQ, lastNames, firstNames,"Pop Quiz");
    }
    //Draw exam bar chart
    public void drawExam()
    {
        int[] exam = new int[students.size()];
        for(int i = 0; i < exam.length; i++)
        {
            exam[i] = students.get(i).getExam();
        }
        BarChart bc = new BarChart(exam, lastNames, firstNames, "Exam");
    }
    //Draw final score bar chart
    public void drawFinalS()
    {
        double[] finalS = new double[students.size()];
        for(int i = 0; i < finalS.length; i++)
        {
            finalS[i] = Double.parseDouble(students.get(i).getFinalS());
        }
        BarChart2 bc = new BarChart2(finalS, lastNames, firstNames,"Final Score");
    }
}
