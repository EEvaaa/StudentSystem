import javax.swing.*; 
import javax.swing.event.*; 
import java.awt.*; 
import java.awt.event.*; 
public class Calculator extends JFrame implements ActionListener { 
    Result result = new Result(); 
    Number_Key number_key = new Number_Key();
    boolean com = false; 
    int i = 0; 
    String text = ""; 
    double defbutton = 0; 
    int symbol = 0; 
    Calculator() 
    { 
        super("My Calculator");   
        JPanel pane = new JPanel();    

        pane.setLayout(new BorderLayout()); 
        setBounds(380,220,30,80);

        pane.add(result, BorderLayout.NORTH); 
        pane.add(number_key, BorderLayout.CENTER);
        pane.add(number_key.equal, BorderLayout.SOUTH);

        number_key.one.addActionListener(this);    
        number_key.two.addActionListener(this);   
        number_key.three.addActionListener(this); 
        number_key.four.addActionListener(this); 
        number_key.five.addActionListener(this); 
        number_key.six.addActionListener(this);
        number_key.seven.addActionListener(this);
        number_key.eight.addActionListener(this);
        number_key.nine.addActionListener(this); 
        number_key.zero.addActionListener(this);
        number_key.ce.addActionListener(this);
        number_key.plus.addActionListener(this); 
        number_key.equal.addActionListener(this);
        number_key.sub.addActionListener(this);
        number_key.mul.addActionListener(this); 
        number_key.div.addActionListener(this); 
        number_key.point.addActionListener(this); 

        setContentPane(pane); 
        pack();     
    } 

    public void actionPerformed(ActionEvent e) 
    { 
        // Number 1 
        if (e.getSource() == number_key.one) 
        { 
            if (com || i == 0) 
            { 
                result.text.setText("1"); 
                com = false; 
                i = 1; 
            } 
            else 
            { 
                text = result.text.getText(); 
                result.text.setText(text + "1"); 
            } 
        }
        // Number 2
        else if (e.getSource() == number_key.two) 
        { 
            if (com || i == 0) 
            { 
                result.text.setText("2"); 
                com = false; 
                i = 1; 
            } 
            else 
            { 
                text = result.text.getText(); 
                result.text.setText(text + "2"); 
            } 

        } 
        //Number 3
        else if (e.getSource() == number_key.three) 
        { 
            if (com || i == 0) 
            { 
                result.text.setText("3"); 
                com = false; 
                i = 1; 
            } 
            else 
            { 
                text = result.text.getText(); 
                result.text.setText(text + "3"); 
            } 
        } 
        // Number 4
        else if (e.getSource() == number_key.four) 
        { 
            if (com || i == 0) 
            { 
                result.text.setText("4"); 
                com = false; 
                i = 1; 
            } 
            else 
            { 
                text = result.text.getText(); 
                result.text.setText(text + "4"); 
            } 
        } 
        // Number 5
        else if (e.getSource() == number_key.five) 
        { 
            if (com || i == 0) 
            { 
                result.text.setText("5"); 
                com = false; 
                i = 1; 
            } 
            else 
            { 
                text = result.text.getText(); 
                result.text.setText(text + "5"); 
            } 
        } 
        // Number 6
        else if (e.getSource() == number_key.six) 
        { 
            if (com || i == 0) 
            { 
                result.text.setText("6"); 
                com = false; 
                i = 1; 
            }
            else 
            { 
                text = result.text.getText(); 
                result.text.setText(text + "6"); 
            } 
        } 
        // Number 7
        else if (e.getSource() == number_key.seven) 
        { 
            if (com || i == 0) 
            { 
                result.text.setText("7"); 
                com = false; 
                i = 1; 
            } 
            else 
            { 
                text = result.text.getText(); 
                result.text.setText(text + "7"); 
            } 
        } 
        // Number 8
        else if (e.getSource() == number_key.eight) 
        { 
            if (com || i == 0) 
            { 
                result.text.setText("8"); 
                com = false; 
                i = 1; 
            } 
            else 
            { 
                text = result.text.getText(); 
                result.text.setText(text + "8"); 
            } 
        } 
        // Number 9
        else if (e.getSource() == number_key.nine) 
        { 
            if (com || i == 0) 
            { 
                result.text.setText("9"); 
                com = false; 
                i = 1; 
            } 
            else 
            { 
                text = result.text.getText(); 
                result.text.setText(text + "9"); 
            } 
        }
        // Number 0
        else if (e.getSource() == number_key.zero) 
        { 
            if (com || i == 0) 
            { 
                result.text.setText("0"); 
                com = false; 
                i = 1; 
            } 
            else 
            { 
                text = result.text.getText(); 
                if (Float.parseFloat(text) > 0 || Float.parseFloat(text) < 0) 
                { 
                    result.text.setText(text + "0"); 
                } 
                else 
                { 
                    if (text.trim().indexOf(".") == -1) 
                    { 
                        result.text.setText(text); 
                    } 
                    else 
                    { 
                        result.text.setText(text + "0"); 
                    } 
                } 
            } 
        } 
        else if (e.getSource() == number_key.ce) 
        { 
            result.text.setText("0"); 
            i = 0; 
            com = true; 
        } 
        else if (e.getSource() == number_key.point) 
        { 
            if (com || i == 0) 
            { 
                result.text.setText("0."); 
                com = false; 
                i = 1; 
            } 
            else 
            { 
                text = result.text.getText(); 
                if (text.trim().indexOf(".") == -1) 
                { 
                    result.text.setText(text + "."); 
                } 
                else 
                { 
                    result.text.setText(text); 
                } 
            } 
        }  
        // Plus Sign
        else if (e.getSource() == number_key.plus) 
        { 
            com = true; 
            i = 0; 
            defbutton = Double.parseDouble(result.text.getText()); 
            symbol = 1; 
        }   
        // Minus Sign
        else if (e.getSource() == number_key.sub) 
        { 
            com = true; 
            i = 0; 
            defbutton = Double.parseDouble(result.text.getText()); 
            symbol = 2; 
        }
        //Multiplication sign
        else if (e.getSource() == number_key.mul) 
        { 
            com = true; 
            i = 0; 
            defbutton = Double.parseDouble(result.text.getText()); 
            System.out.println(defbutton); 
            symbol = 3; 
        } 
        //Division sign
        else if (e.getSource() == number_key.div) 
        { 
            com = true; 
            i = 0; 
            defbutton = Double.parseDouble(result.text.getText()); 
            symbol = 4; 
        } 
        else if (e.getSource() == number_key.equal) 
        { 
            switch (symbol) 
            { 
                //Addition
                case 1 :   
                { 
                    double ad = defbutton + Double.parseDouble(result.text.getText()); 
                    result.text.setText(ad + ""); 
                    i = 0; 
                    text = ""; 
                    break; 
                } 
                //Subtraction
                case 2 :
                { 
                    double ad = defbutton - Double.parseDouble(result.text.getText()); 
                    result.text.setText(String.valueOf(ad)); 
                    i = 0; 
                    text = ""; 
                    break; 
                } 
                //Multiplication
                case 3 :
                { 
                    double ad =  defbutton * Double.parseDouble(result.text.getText()); 
                    result.text.setText(ad + ""); 
                    i = 0; 
                    text = ""; 
                    break; 
                } 
                //Division
                case 4 :
                { 
                    double ad = defbutton / Double.parseDouble(result.text.getText()); 
                    result.text.setText(ad + ""); 
                    i = 0; 
                    text = ""; 
                    break; 
                } 
            }
            System.out.println(com); 
        } 
    } 
} 

class Number_Key extends JPanel 
{ 

    JButton zero = new JButton("0");      
    JButton one = new JButton("1");  
    JButton two = new JButton("2"); 
    JButton three = new JButton("3"); 
    JButton four = new JButton("4"); 
    JButton five = new JButton("5"); 
    JButton six = new JButton("6");
    JButton seven = new JButton("7");
    JButton eight = new JButton("8"); 
    JButton nine = new JButton("9");
    JButton plus = new JButton("+"); 
    JButton sub = new JButton("-"); 
    JButton mul = new JButton("*"); 
    JButton div = new JButton("/"); 
    JButton equal = new JButton("="); 
    JButton ce = new JButton("Delete"); 
    JButton point = new JButton("."); 

    Number_Key() { 
        setLayout(new GridLayout(4, 4, 1, 1)); 
        setBackground(Color.blue);   
        add(one);             
        add(two);
        add(three);
        add(four); 
        add(five); 
        add(six); 
        add(seven); 
        add(eight); 
        add(nine); 
        add(zero);  
        add(plus); 
        add(sub); 
        add(mul); 
        add(div); 
        add(point); 
        add(equal); 
        add(ce);  
    } 
} 

class Result extends JPanel 
{ 
    JTextField text = new JTextField("0"); 
    Result() 
    {  
        text.setHorizontalAlignment(SwingConstants.RIGHT); 
        text.enable(false);
        setLayout(new BorderLayout()); 
        add(text, BorderLayout.CENTER);
    } 
}
