import javax.swing.*;
import java.awt.*;
import java.util.*;
public class BarChart2 extends JFrame
{
    private final int LEFT_MARGIN = 100;        // starting x coordinate
    private final int BASE_Y_BAR  = 320;       // bottom of the bars
    private final int BASE_Y_VALUE = 350;      // bottom of the values
    private int BAR_WIDTH;          // width of each bar
    private int SPACE_BETWEEN_BARS;  // pixels between bars

    private double [ ] grade;
    private String[] last;
    private String[] first;
    public BarChart2(double[] numbers, String[] last, String[] first,String title)
    {
        grade = numbers;
        this.first = first;
        this.last = last;
        this.setTitle(title);
        setSize( 650, 400 );
        setLocation(400,250);
        setResizable(false);
        setVisible( true );
    }

    public void paint( Graphics g )
    {

        super.paint( g );
        Random rnd = new Random();
        int x = 0;
        int y = 0;
        int z = 0;         // bars will be blue
        int xStart = LEFT_MARGIN;          // x value for first bar
        BAR_WIDTH = 350 / grade.length;
        SPACE_BETWEEN_BARS = 100/ (grade.length-1);
        g.drawString("Name", 30, 450);
        g.drawString("Grade", 30, 100);
        for ( int i = 0; i < grade.length; i++ )
        {
            x = rnd.nextInt(256);
            y = rnd.nextInt(256);
            z = rnd.nextInt(256);
            Color rcolor =  new Color(x,y,z);
            g.setColor(rcolor);
            g.fillRect( xStart, BASE_Y_BAR - ( int )( grade[i] )-50,
                BAR_WIDTH, ( int )( grade[i] )+50);

            g.drawString( Double.toString( grade[i] ),
                xStart, BASE_Y_VALUE );
            //Write last name
            g.drawString(last[i], xStart, BASE_Y_VALUE+20);
            //Write first name
            g.drawString(first[i], xStart, BASE_Y_VALUE+40);
            xStart += BAR_WIDTH + SPACE_BETWEEN_BARS;
        }
    }   
}
