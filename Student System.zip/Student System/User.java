import java.io.Serializable;
public class User implements Serializable
{
    // instance variables
    private String userName;
    private String password;
    private String answer;
    private static int numUsers;

    /**
     * Constructor for objects of class User
     */
    public User(String userName, String password, String answer)
    {
        this.userName = userName;
        this.password = password;
        this.answer = answer;
        numUsers = numUsers + 1;
    }
    
    // get username
    public String getUserName()
    {
        return userName;
    }
    // get password
    public String getPassword()
    {
        return password;
    }
    // get answer of the security question
    public String getAnswer()
    {
        return answer;
    }
    //set username
    public void setUserName(String userName)
    {
        this.userName = userName;
    }
    // set password
    public void setPassword(String password)
    {
        this.password = password;
    }
    // set answer
    public void setAnswer(String answer)
    {
        this.answer = answer;
    }
    // get the number of users
    public static int getNumUsers()
    {
        return numUsers;
    }
}