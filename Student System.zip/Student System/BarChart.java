import javax.swing.*;
import java.awt.*;
import java.util.*;
public class BarChart extends JFrame
{
    private final int LEFT_MARGIN = 100;        // starting x coordinate
    private final int BASE_Y_BAR  = 320;       // bottom of the bars
    private final int BASE_Y_VALUE = 350;      // bottom of the values
    private int BAR_WIDTH;          // width of each bar
    private int SPACE_BETWEEN_BARS;  // pixels between bars

    private int [ ] grade;
    private String[] last;
    private String[] first;
    private JLabel lblX, lblY;
    private String title;
    public BarChart(int[] numbers, String[] last, String[] first, String title)
    {
        //Initiate variables
        grade = numbers;
        this.first = first;
        this.last = last;
        this.title = title;
        //set size, location of the frame
        setSize( 650, 400 );
        setLocation(400,250);
        //setResizable(false);
        setVisible( true );
    }

    public void paint( Graphics g )
    {
        super.paint( g );
        Random rnd = new Random();
        int x = 0;
        int y = 0;
        int z = 0;
        // x value for first bar
        int xStart = LEFT_MARGIN;
        // bar width changes referred to the number of students
        BAR_WIDTH = 350 / grade.length;
        SPACE_BETWEEN_BARS = 100/ (grade.length-1);
        // mark out x,y axes
        g.drawString("Name", 30, 350);
        g.drawString("Grade", 30, 100);
        if(title == "Assignment")
        {
            for ( int i = 0; i < grade.length; i++ )
            { 
                // Set random color for each column
                x = rnd.nextInt(256);
                y = rnd.nextInt(256);
                z = rnd.nextInt(256);
                Color rcolor =  new Color(x,y,z);
                g.setColor(rcolor);
                g.fillRect( xStart, BASE_Y_BAR - ( int )( grade[i] )*8,
                    BAR_WIDTH, ( int )( grade[i] )*8 );

                g.drawString( Double.toString( grade[i] ),
                    xStart, BASE_Y_VALUE );
                //draw last names and first names of each student
                g.drawString(last[i], xStart, BASE_Y_VALUE+20);
                g.drawString(first[i], xStart, BASE_Y_VALUE+40);
                xStart += BAR_WIDTH + SPACE_BETWEEN_BARS;
            }
        }
        else if(title == "Participation")
        {
            for ( int i = 0; i < grade.length; i++ )
            { 
                // Set random color for each column
                x = rnd.nextInt(256);
                y = rnd.nextInt(256);
                z = rnd.nextInt(256);
                Color rcolor =  new Color(x,y,z);
                g.setColor(rcolor);
                g.fillRect( xStart, BASE_Y_BAR - ( int )( grade[i] )*15,
                    BAR_WIDTH, ( int )( grade[i] )*15 );

                g.drawString( Double.toString( grade[i] ),
                    xStart, BASE_Y_VALUE );
                //draw last names and first names of each student
                g.drawString(last[i], xStart, BASE_Y_VALUE+20);
                g.drawString(first[i], xStart, BASE_Y_VALUE+40);
                xStart += BAR_WIDTH + SPACE_BETWEEN_BARS;
            }
        }
        else if(title == "Pop Quiz")
        {
             for ( int i = 0; i < grade.length; i++ )
            { 
                // Set random color for each column
                x = rnd.nextInt(256);
                y = rnd.nextInt(256);
                z = rnd.nextInt(256);
                Color rcolor =  new Color(x,y,z);
                g.setColor(rcolor);
                g.fillRect( xStart, BASE_Y_BAR - ( int )( grade[i] )*15,
                    BAR_WIDTH, ( int )( grade[i] )*15 );

                g.drawString( Double.toString( grade[i] ),
                    xStart, BASE_Y_VALUE );
                //draw last names and first names of each student
                g.drawString(last[i], xStart, BASE_Y_VALUE+20);
                g.drawString(first[i], xStart, BASE_Y_VALUE+40);
                xStart += BAR_WIDTH + SPACE_BETWEEN_BARS;
            }
        }
        else if(title == "Exam")
        {
            for ( int i = 0; i < grade.length; i++ )
            { 
                // Set random color for each column
                x = rnd.nextInt(256);
                y = rnd.nextInt(256);
                z = rnd.nextInt(256);
                Color rcolor =  new Color(x,y,z);
                g.setColor(rcolor);
                g.fillRect( xStart, BASE_Y_BAR - ( int )( grade[i] )-50,
                    BAR_WIDTH, ( int )( grade[i] )+50 );

                g.drawString( Double.toString( grade[i] ),
                    xStart, BASE_Y_VALUE );
                //draw last names and first names of each student
                g.drawString(last[i], xStart, BASE_Y_VALUE+20);
                g.drawString(first[i], xStart, BASE_Y_VALUE+40);
                xStart += BAR_WIDTH + SPACE_BETWEEN_BARS;
            }
        }
    }
}
