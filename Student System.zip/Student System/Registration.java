import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.IOException;
public class Registration extends JFrame
{
    private Container contents;
    private JTextField txtID, newID,txtAns;
    private JLabel labelNewID,labelNP,lblAns;
    private JPasswordField password, nPassword;
    private JButton btnRegister;
    private ArrayList<User> users;
    public Registration()
    {
        super("Registration");
        contents = getContentPane();
        contents.setLayout(new BorderLayout());
        contents.add(register(),BorderLayout.NORTH);
        contents.add(button(),BorderLayout.SOUTH);
        
        FileIO io = new FileIO();

        users = io.loadUsers("Accounts");

        setSize(600,200);
        this.setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }
    //GUI of registration
    public JComponent register()
    {
        JPanel panel = new JPanel(new GridLayout(3,2,10,10));

        labelNewID = new JLabel("New ID");
        labelNewID.setHorizontalAlignment(SwingConstants.RIGHT);
        txtID = new JTextField("",12);
        panel.add(labelNewID);
        panel.add(txtID);
        
        labelNP = new JLabel("Enter Password");
        labelNP.setHorizontalAlignment(SwingConstants.RIGHT);
        password = new JPasswordField("",12);
        password.setEchoChar('*');
        panel.add(labelNP);
        panel.add(password);
        
        lblAns = new JLabel("Security Question: What is your father's name?");
        lblAns.setHorizontalAlignment(SwingConstants.RIGHT);
        txtAns = new JTextField("",12);
        panel.add(lblAns);
        panel.add(txtAns);
        
        add(panel);
        setLayout(new FlowLayout());
        setLocationRelativeTo(null);//居中
        
        return panel;
    }
    
    public JComponent button()
    {   
        JPanel panel = new JPanel(new GridLayout(1,1,10,10));
        btnRegister = new JButton("Register");
        panel.add(btnRegister);
        
        Action ac= new Action();
        btnRegister.addActionListener(ac);
        
        add(panel);
        setLayout(new FlowLayout());
        setLocationRelativeTo(null);//居中
        return panel;
    }
    
    private class Action implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            //Get information from text fields
            String userName = txtID.getText();
            String userPassword = password.getText();
            String answer = txtAns.getText();
            //Save the account in the "Accounts" file
            if(e.getSource() == btnRegister)
            {
                users.add(new User(userName, userPassword,answer));
                FileIO io = new FileIO();
                io.saveUsers(users, "Accounts");
                dispose();
            }
        }
    }
}
