import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
public class Login extends JFrame
{
    private Container contents;
    private JTextField txtID, newID;
    private JLabel labelID, labelNewID,labelPassword,labelNP, labelMessage;
    private JPasswordField password, nPassword;
    private JButton btnLogin, btnRegister, btnFind;
    private ArrayList<User> users;
    private FileIO io;
    public Login()
    {
        super("Welcome to the Student System");
        contents = getContentPane();
        contents.setLayout(new BorderLayout());

        contents.add(topPane(), BorderLayout.NORTH);
        contents.add(bottomPane(), BorderLayout.SOUTH);

        FileIO io = new FileIO();
        users = io.loadUsers("Accounts");

        setSize(400,300);
        this.setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }
    //GUI of main interface
    public JComponent topPane()
    {
        JPanel panel = new JPanel(new GridLayout(2,2,20,20));

        labelID = new JLabel("Enter Username");
        labelID.setHorizontalAlignment(SwingConstants.RIGHT);
        txtID = new JTextField("",12);
        panel.add(labelID);
        panel.add(txtID);

        labelPassword = new JLabel("Enter Password");
        labelPassword.setHorizontalAlignment(SwingConstants.RIGHT);
        password = new JPasswordField("",12);
        password.setEchoChar('*');
        panel.add(labelPassword);
        panel.add(password);

        add(panel);
        setLayout(new FlowLayout());
        setLocationRelativeTo(null);//居中

        return panel;
    }
    //Function buttons 
    public JComponent bottomPane()
    {
        JPanel panel = new JPanel(new GridLayout(3,1,20,20));
        btnLogin = new JButton("Login");
        btnLogin.setHorizontalAlignment(SwingConstants.CENTER);
        btnRegister = new JButton("Register");
        btnRegister.setHorizontalAlignment(SwingConstants.CENTER);
        btnFind = new JButton("Find");
        btnFind.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(btnLogin);
        panel.add(btnRegister);
        panel.add(btnFind);

        Action ac= new Action();
        btnLogin.addActionListener(ac);
        btnRegister.addActionListener(ac);
        btnFind.addActionListener(ac);

        add(panel);
        setLayout(new FlowLayout());
        setLocationRelativeTo(null);//居中

        return panel;
    }

    public int searchUsers(String userName)
    {
        int index = -1;
        if(!users.isEmpty())
        {
            for(int i = 0; i < users.size(); i++)
            {
                if(users.get(i).getUserName().equals(userName))
                {
                    return i;
                }
            }
        }
        return index;
    }

    private class Action implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            try
            {
                String userName = txtID.getText();
                String userPassword = password.getText();
                //Login 
                if(e.getSource() == btnLogin)
                {                    
                    FileIO io = new FileIO();
                    users = io.loadUsers("Accounts");
                    int index = searchUsers(userName);
                    if(index != -1)
                    {                        
                        if(userName.equals(users.get(index).getUserName()) && userPassword.equals(users.get(index).getPassword()))
                        {
                            JOptionPane.showMessageDialog(null,"Welcome, " + users.get(index).getUserName());
                            dispose();
                            StudentSystem ss = new StudentSystem();
                        }
                        else
                        {
                            JOptionPane.showConfirmDialog(null, "Please check your username and password." + "\n" + 
                                "If you have not ever registered, please click Register button.", "Error", JOptionPane.ERROR_MESSAGE);
                        }                        
                    }
                    else 
                    {
                        int output = JOptionPane.showConfirmDialog(null, "No user found. Would you like to create a new account?", "Welcome to my app", 
                                JOptionPane.YES_NO_OPTION);
                        //Shwoing the YES or NO to create new use account
                        //Checking the options
                        if(output == JOptionPane.YES_OPTION)
                        {
                            txtID.setText("");
                            password.setText("");
                            Registration r = new Registration();
                        }
                        else if(output == JOptionPane.NO_OPTION)
                        {
                            System.exit(0);
                        }
                    }
                }
                //Registration
                else if(e.getSource() == btnRegister)
                {
                    txtID.setText("");
                    password.setText("");
                    Registration r = new Registration();
                }
                //Find Password
                else if(e.getSource() == btnFind)
                {
                    String target = JOptionPane.showInputDialog(null, "Enter your user name: ");
                    int a = -1;
                    for(int i = 0; i < users.size(); i++)
                    {
                        if(users.get(i).getUserName().equals(target))
                        {
                            a = i;
                        }
                    }
                    //If the username does not exist
                    if(a == -1)
                    {
                        JOptionPane.showMessageDialog(null, "No username of " + target + " is found.");
                    }
                    //The username exists
                    else
                    {
                        String targetSQ = JOptionPane.showInputDialog(null, "Enter the answer of Security Question (What is your father's first name?)");
                        if(users.get(a).getAnswer().equals(targetSQ))
                        {
                            String email = JOptionPane.showInputDialog(null, "what is your email?");
                            JOptionPane.showConfirmDialog(null, "Your email: " + email, "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                            boolean confirmation = false;
                            //Send email to users
                            String password = "Your password is " + users.get(a).getPassword();
                            String name = users.get(a).getUserName();
                            JavaMail jm = new JavaMail();
                            jm.sendMail(name, password, email);
                            confirmation = true;

                        }
                        else
                        {
                            JOptionPane.showConfirmDialog(null, "Sorry the answer of security question is incorrect.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                JOptionPane.showMessageDialog(null, "Unknown error", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
